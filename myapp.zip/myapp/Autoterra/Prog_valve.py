from Déf_valeurs_intervalle import *
from Affichage_humidité import *

def valve():
    if humid < humid1:
        #ouverture valve
        print("L'humidité est inférieur par rapport à l'intervalle : ouverture de la valve")
    elif humid > humid2:
        #fermeture de la valve
        print("L'humidité est supérieur par rapport à l'intervalle : fermeture de la valve")
    else:
        print("L'humidité est bien comprise dans l'intervalle : tout est bon")