from django.shortcuts import render
from django.views import generic
from django.views.generic import ListView
from .forms import Humidite
from django.http import HttpResponseRedirect
from .models import Bibliotheque
import random

def index(request):
    num_Bibliotheque = Bibliotheque.objects.all().count()
    context = {'num_Bibliotheque': num_Bibliotheque,}
    return render(request, 'index.html', context=context)

def affichage(request):
    valeur_humidite = random.randint(0, 100)
    context = {
        'valeur_humidite': valeur_humidite,
    }
    return render(request, 'Affichage.html',context=context)

def get_Humidite(request):
    if request.method == 'post':
        form = Humidite(request.post)
        valeur_humidite = random.randint(0, 100)
        if form.is_valid():
            return HttpResponseRedirect('/Ok/')
    else:
        form = Humidite()
    return  render(request,'Humidite.html',{'form':form})

def validation_humidite(request):
    valeur_humidite = random.randint(0, 100)
    context = {
        'valeur_humidite': valeur_humidite,
    }
    return render(request, 'validation_humidite.html', context=context)

class BibliothequeListView(generic.ListView):
    model = Bibliotheque
    context_object_name = 'Bibliotheque_list'   # your own name for the list as a template variable
    template_name = 'Bibliotheque_liste.html'  # Specify your own template name/location

class BibliothequeDetailView(generic.DetailView):
    model = Bibliotheque
    def Bibliotheque_detail_view(request, primary_key):
        try:
            Bibliotheque = Bibliotheque.objects.get(pk=primary_key)
        except Bibliotheque.DoesNotExist:
            raise Http404('Bibliotheque does not exist')
        return render(request, '.html', context={'Bibliotheque': Bibliotheque})