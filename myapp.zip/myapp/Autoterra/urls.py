from django.urls import include
from django.urls import path
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    #path('Autoterra/', include('Autoterra.urls')),
    path('', views.index, name='index'),
    path('Affichage/',views.affichage, name='Affichage'),
    path('Humidite/',views.get_Humidite, name='Humidite'),
    path('Humidite/v',views.validation_humidite, name= 'validation_humidite'),
    path('Bibliotheque/', views.BibliothequeListView.as_view(), name='Bibliotheque'),
    path('Bibliotheque/<int:pk>', views.BibliothequeDetailView.as_view(), name='bibliotheque_detail'),
]