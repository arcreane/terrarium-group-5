from django.db import models
from django.urls import reverse

class Affichage(models.Model):
    # Fields
    Title = models.CharField(max_length=100, help_text='Nom')
    Humidite = models.IntegerField(help_text='Humidite')
    Temperature = models.IntegerField(help_text='Température')
    # Metadata
    class Meta:
        ordering = ['Title','Humidite','Temperature']
    # Methods
    def __str__(self):
        return self.Title
    def get_absolute_url(self):
        return reverse('humidite_detail', args=[str(self.id)])

class Bibliotheque(models.Model):
    # Fields
    Animal = models.CharField(max_length=100, help_text='Animal')
    Image = models.ImageField()
    Humidite_min = models.IntegerField(help_text='Humidite pourcentage min')
    Humidite_max = models.IntegerField(help_text='Humidite pourcentage max')
    # Metadata
    class Meta:
        ordering = ['Animal','Image','Humidite_min','Humidite_max']
    # Methods
    def __str__(self):
        return self.Animal
    def get_absolute_url(self):
        return reverse('bibliotheque_detail', args=[str(self.id)])